<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meme Generator Service</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        .card {
            background-color: #f5f5f5;
            border-radius: 5px;
            padding: 20px;
            margin-top: 20px;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
    </style>
</head>
<body>
<h1>Meme Generator Web Service</h1>

<div class="card">
    <h2>API Documentation</h2>
    <p>This service provides a simple API to generate memes using the Meme Maker API.</p>

    <h3>GET /meme</h3>
    <p>Generate a meme with the specified parameters.</p>
    <p><strong>Parameters:</strong></p>
    <ul>
        <li><code>template</code> - The meme template name (required)</li>
        <li><code>top_text</code> - The text for the top of the meme (optional)</li>
        <li><code>bottom_text</code> - The text for the bottom of the meme (optional)</li>
    </ul>

    <h3>POST /meme</h3>
    <p>Generate a meme with JSON request body.</p>
    <p><strong>Example JSON Body:</strong></p>
    <pre>
{
  "template": "doge",
  "top_text": "such web service",
  "bottom_text": "much distributed"
}
        </pre>
</div>

<a href="dashboard">View Dashboard</a>
</body>
</html>