package ds.memegeneratorservice;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Sorts;
import org.bson.Document;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Servlet that displays the dashboard with logs and analytics.
 *
 * @author Madison Shen, mshen3
 */
@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> logCollection;

    @Override
    public void init() throws ServletException {
        super.init();

        // MongoDB Connection String
        //String connectionString = "mongodb+srv://memeuser:jrCJYtZAbMKEfEGi@cluster0.7cbew.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

        String connectionString = System.getenv("MONGODB_URI");
        if (connectionString == null || connectionString.isEmpty()) {
            connectionString = "mongodb+srv://memeuser:jrCJYtZAbMKEfEGi@cluster0.7cbew.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        }

        try {
            // Initialize MongoDB client
            System.out.println("Attempting to connect to MongoDB...");
            mongoClient = MongoClients.create(connectionString);
            System.out.println("MongoDB client created successfully");

            database = mongoClient.getDatabase("proj4memedb");
            System.out.println("Connected to database: " + database.getName());

            logCollection = database.getCollection("meme_logs");
            System.out.println("Connected to collection: meme_logs");

        } catch (Exception e) {
            System.err.println("MongoDB connection error: " + e.getMessage());
            e.printStackTrace();
            //throw new ServletException("Failed to connect to MongoDB", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");

        try {
            // Check if MongoDB connection is working
            if (mongoClient == null || database == null || logCollection == null) {
                throw new ServletException("MongoDB connection is not available");
            }

            // Perform analytics queries

            // 1. Top 5 meme templates used
            List<Document> topTemplates = new ArrayList<>();
            logCollection.aggregate(Arrays.asList(
                    Aggregates.match(new Document("parameters.template", new Document("$exists", true))),
                    Aggregates.group("$parameters.template", Accumulators.sum("count", 1)),
                    Aggregates.sort(Sorts.descending("count")),
                    Aggregates.limit(5)
            )).into(topTemplates);

            // 2. Average API response time
            Document avgResponseTime = logCollection.aggregate(Arrays.asList(
                    Aggregates.match(new Document("api_response_time_ms", new Document("$exists", true))),
                    Aggregates.group(null, Accumulators.avg("average", "$api_response_time_ms"))
            )).first();

            double averageApiResponseTime = 0;
            if (avgResponseTime != null && avgResponseTime.containsKey("average")) {
                averageApiResponseTime = avgResponseTime.getDouble("average");
            }

            // 3. Count of requests by device type (based on User-Agent)
            List<Document> deviceStats = new ArrayList<>();
            logCollection.aggregate(Arrays.asList(
                    Aggregates.match(new Document("user_agent", new Document("$exists", true))),
                    Aggregates.project(new Document("device_type",
                            new Document("$cond", Arrays.asList(
                                    new Document("$regexMatch", new Document("input", "$user_agent").append("regex", "Android")),
                                    "Android",
                                    new Document("$cond", Arrays.asList(
                                            new Document("$regexMatch", new Document("input", "$user_agent").append("regex", "iPhone|iPad|iPod")),
                                            "iOS",
                                            "Other"
                                    ))
                            ))
                    )),
                    Aggregates.group("$device_type", Accumulators.sum("count", 1)),
                    Aggregates.sort(Sorts.descending("count"))
            )).into(deviceStats);

            // Get all logs for display, limiting to most recent 100
            List<Document> allLogs = new ArrayList<>();
            logCollection.find(new Document("event", "request_received"))
                    .sort(new Document("timestamp", -1))
                    .limit(100)
                    .into(allLogs);

            // Build HTML response
            StringBuilder htmlBuilder = new StringBuilder();
            htmlBuilder.append("<!DOCTYPE html>\n")
                    .append("<html lang=\"en\">\n")
                    .append("<head>\n")
                    .append("    <meta charset=\"UTF-8\">\n")
                    .append("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n")
                    .append("    <title>Meme Generator Dashboard</title>\n")
                    .append("    <style>\n")
                    .append("        body { font-family: Arial, sans-serif; margin: 20px; }\n")
                    .append("        h1 { color: #333; }\n")
                    .append("        h2 { color: #666; margin-top: 30px; }\n")
                    .append("        table { border-collapse: collapse; width: 100%; margin-top: 10px; }\n")
                    .append("        th, td { text-align: left; padding: 8px; border: 1px solid #ddd; }\n")
                    .append("        th { background-color: #f2f2f2; }\n")
                    .append("        tr:nth-child(even) { background-color: #f9f9f9; }\n")
                    .append("        .analytics-container { display: flex; flex-wrap: wrap; gap: 20px; }\n")
                    .append("        .analytics-card { flex: 1; min-width: 300px; background-color: #f2f2f2; padding: 15px; border-radius: 5px; }\n")
                    .append("        .refresh-button { padding: 10px 15px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; }\n")
                    .append("    </style>\n")
                    .append("</head>\n")
                    .append("<body>\n")
                    .append("    <h1>Meme Generator Dashboard</h1>\n")
                    .append("    <button class=\"refresh-button\" onclick=\"location.reload()\">Refresh Dashboard</button>\n")

                    // Analytics Section
                    .append("    <h2>Operations Analytics</h2>\n")
                    .append("    <div class=\"analytics-container\">\n")

                    // Top Templates
                    .append("        <div class=\"analytics-card\">\n")
                    .append("            <h3>Top 5 Meme Templates</h3>\n")
                    .append("            <table>\n")
                    .append("                <tr><th>Template</th><th>Count</th></tr>\n");

            // Add top templates data
            for (Document template : topTemplates) {
                htmlBuilder.append("                <tr><td>")
                        .append(template.getString("_id"))
                        .append("</td><td>")
                        .append(template.getInteger("count"))
                        .append("</td></tr>\n");
            }

            htmlBuilder.append("            </table>\n")
                    .append("        </div>\n")

                    // Average API Response Time
                    .append("        <div class=\"analytics-card\">\n")
                    .append("            <h3>API Performance</h3>\n")
                    .append("            <p>Average API Response Time: ")
                    .append(String.format("%.2f", averageApiResponseTime))
                    .append(" ms</p>\n")
                    .append("        </div>\n")

                    // Device Types
                    .append("        <div class=\"analytics-card\">\n")
                    .append("            <h3>Requests by Device Type</h3>\n")
                    .append("            <table>\n")
                    .append("                <tr><th>Device Type</th><th>Count</th></tr>\n");

            // Add device stats data
            for (Document device : deviceStats) {
                htmlBuilder.append("                <tr><td>")
                        .append(device.getString("_id"))
                        .append("</td><td>")
                        .append(device.getInteger("count"))
                        .append("</td></tr>\n");
            }

            htmlBuilder.append("            </table>\n")
                    .append("        </div>\n")
                    .append("    </div>\n")

                    // Logs Section
                    .append("    <h2>Request Logs</h2>\n")
                    .append("    <table>\n")
                    .append("        <tr>\n")
                    .append("            <th>Timestamp</th>\n")
                    .append("            <th>Method</th>\n")
                    .append("            <th>Template</th>\n")
                    .append("            <th>Top Text</th>\n")
                    .append("            <th>Bottom Text</th>\n")
                    .append("            <th>Client IP</th>\n")
                    .append("            <th>User Agent</th>\n")
                    .append("            <th>Status</th>\n")
                    .append("            <th>Response Time (ms)</th>\n")
                    .append("        </tr>\n");

            // Add log entries
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            for (Document log : allLogs) {
                String timestamp = log.getDate("timestamp") != null ?
                        dateFormat.format(log.getDate("timestamp")) : "N/A";

                String method = log.getString("method") != null ?
                        log.getString("method") : "N/A";

                Document params = log.get("parameters", Document.class);
                String template = params != null && params.getString("template") != null ?
                        params.getString("template") : "N/A";

                String topText = params != null && params.getString("top_text") != null ?
                        params.getString("top_text") : "N/A";

                String bottomText = params != null && params.getString("bottom_text") != null ?
                        params.getString("bottom_text") : "N/A";

                String clientIp = log.getString("client_ip") != null ?
                        log.getString("client_ip") : "N/A";

                String userAgent = log.getString("user_agent") != null ?
                        log.getString("user_agent") : "N/A";

                // Truncate user agent if too long
                if (userAgent.length() > 50) {
                    userAgent = userAgent.substring(0, 47) + "...";
                }

                String status = log.getString("status") != null ?
                        log.getString("status") : "N/A";

                String responseTime = log.containsKey("response_time_ms") ?
                        log.get("response_time_ms").toString() : "N/A";

                htmlBuilder.append("        <tr>\n")
                        .append("            <td>").append(timestamp).append("</td>\n")
                        .append("            <td>").append(method).append("</td>\n")
                        .append("            <td>").append(template).append("</td>\n")
                        .append("            <td>").append(topText).append("</td>\n")
                        .append("            <td>").append(bottomText).append("</td>\n")
                        .append("            <td>").append(clientIp).append("</td>\n")
                        .append("            <td title=\"").append(userAgent).append("\">")
                        .append(userAgent).append("</td>\n")
                        .append("            <td>").append(status).append("</td>\n")
                        .append("            <td>").append(responseTime).append("</td>\n")
                        .append("        </tr>\n");
            }

            htmlBuilder.append("    </table>\n")
                    .append("</body>\n")
                    .append("</html>");

            // Send the HTML response
            response.getWriter().write(htmlBuilder.toString());

        } catch (Exception e) {
            System.err.println("Error in dashboard: " + e.getMessage());
            e.printStackTrace();

            // Send error page instead of the dashboard
            StringBuilder errorHtml = new StringBuilder();
            errorHtml.append("<!DOCTYPE html>\n")
                    .append("<html lang=\"en\">\n")
                    .append("<head>\n")
                    .append("    <meta charset=\"UTF-8\">\n")
                    .append("    <title>Dashboard Error</title>\n")
                    .append("    <style>body {font-family: Arial; padding: 20px; text-align: center;}</style>\n")
                    .append("</head>\n")
                    .append("<body>\n")
                    .append("    <h1>Dashboard Error</h1>\n")
                    .append("    <p>The dashboard is currently unavailable: ").append(e.getMessage()).append("</p>\n")
                    .append("    <p>MongoDB connection may be blocked by network restrictions in GitHub Codespaces.</p>\n")
                    .append("    <a href=\"/\">Return to Home</a>\n")
                    .append("</body>\n")
                    .append("</html>");

            response.getWriter().write(errorHtml.toString());
        }


    }

    @Override
    public void destroy() {
        // Close MongoDB connection
        if (mongoClient != null) {
            mongoClient.close();
        }

        super.destroy();
    }
}