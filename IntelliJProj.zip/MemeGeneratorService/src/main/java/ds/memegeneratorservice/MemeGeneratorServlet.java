package ds.memegeneratorservice;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.json.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Date;
import java.util.stream.Collectors;

/**
 * Servlet that handles meme generation requests.
 *
 * @author Madison Shen, mshen3
 */
@WebServlet("/meme")
public class MemeGeneratorServlet extends HttpServlet {

    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> logCollection;

    @Override
    public void init() throws ServletException {
        super.init();

        // MongoDB Connection String
        String connectionString = "mongodb+srv://memeuser:jrCJYtZAbMKEfEGi@cluster0.7cbew.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

        try {
            // Initialize MongoDB client
            System.out.println("Attempting to connect to MongoDB...");
            mongoClient = MongoClients.create(connectionString);
            System.out.println("MongoDB client created successfully");

            database = mongoClient.getDatabase("proj4memedb");
            System.out.println("Connected to database: " + database.getName());

            logCollection = database.getCollection("meme_logs");
            System.out.println("Connected to collection: meme_logs");

            // Log server start
            Document serverStartLog = new Document("event", "server_start")
                    .append("timestamp", new Date());
            logCollection.insertOne(serverStartLog);
            System.out.println("Server start logged successfully");

        } catch (Exception e) {
            System.err.println("MongoDB connection error: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("Failed to connect to MongoDB", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set response type
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try {
            // Start logging the request
            long requestStartTime = System.currentTimeMillis();
            Document requestLog = new Document("event", "request_received")
                    .append("timestamp", new Date())
                    .append("method", "GET")
                    .append("path", request.getRequestURI())
                    .append("client_ip", request.getRemoteAddr())
                    .append("user_agent", request.getHeader("User-Agent"));

            // Extract parameters
            String template = request.getParameter("template");
            String topText = request.getParameter("top_text");
            String bottomText = request.getParameter("bottom_text");

            // Validate input
            if (template == null || template.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                JSONObject errorJson = new JSONObject();
                errorJson.put("error", "Missing template parameter");
                out.print(errorJson.toString());

                // Log error
                requestLog.append("status", "error")
                        .append("error_message", "Missing template parameter");
                logCollection.insertOne(requestLog);
                return;
            }

            if (topText == null) topText = "";
            if (bottomText == null) bottomText = "";

            // Encode parameters for URL
            String encodedTemplate = URLEncoder.encode(template, "UTF-8");
            String encodedTopText = encodeForMeme(topText);
            String encodedBottomText = encodeForMeme(bottomText);

            // Construct API URL
            String apiUrl = String.format("https://api.memegen.link/images/%s/%s/%s",
                    encodedTemplate, encodedTopText, encodedBottomText);

            requestLog.append("parameters", new Document("template", template)
                            .append("top_text", topText)
                            .append("bottom_text", bottomText))
                    .append("api_url", apiUrl);

            // Log API request start time
            long apiRequestStartTime = System.currentTimeMillis();
            requestLog.append("api_request_start_time", new Date());

            // Call the Meme Generator API
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            // Check if the API call was successful
            int responseCode = conn.getResponseCode();

            // Log API response
            long apiRequestEndTime = System.currentTimeMillis();
            requestLog.append("api_request_end_time", new Date())
                    .append("api_response_time_ms", apiRequestEndTime - apiRequestStartTime)
                    .append("api_response_code", responseCode);

            JSONObject responseJson = new JSONObject();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Create JSON response
                responseJson.put("success", true);
                responseJson.put("url", apiUrl);
                responseJson.put("template", template);
                responseJson.put("top_text", topText);
                responseJson.put("bottom_text", bottomText);

                // Set response status
                response.setStatus(HttpServletResponse.SC_OK);

                // Log success
                requestLog.append("status", "success");
            } else {
                // Read error message from the API
                BufferedReader errorReader = new BufferedReader(
                        new InputStreamReader(conn.getErrorStream()));
                String errorContent = errorReader.lines().collect(Collectors.joining());
                errorReader.close();

                // Create error JSON response
                responseJson.put("success", false);
                responseJson.put("error", "API Error");
                responseJson.put("message", "Failed to generate meme");
                responseJson.put("api_error", errorContent);

                // Set response status
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);

                // Log error
                requestLog.append("status", "error")
                        .append("error_message", "API Error: " + errorContent);
            }

            // Send response
            out.print(responseJson.toString());

            // Log response time
            long requestEndTime = System.currentTimeMillis();
            requestLog.append("response_time_ms", requestEndTime - requestStartTime)
                    .append("response_sent", responseJson.toString());

            // Insert the complete log document
            logCollection.insertOne(requestLog);

        } catch (Exception e) {
            // Handle unexpected errors
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            JSONObject errorJson = new JSONObject();
            errorJson.put("success", false);
            errorJson.put("error", "Server Error");
            errorJson.put("message", e.getMessage());
            out.print(errorJson.toString());

            // Log error
            Document errorLog = new Document("event", "server_error")
                    .append("timestamp", new Date())
                    .append("error_type", e.getClass().getName())
                    .append("error_message", e.getMessage())
                    .append("path", request.getRequestURI())
                    .append("method", "GET");
            logCollection.insertOne(errorLog);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set response type
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try {
            // Start logging the request
            long requestStartTime = System.currentTimeMillis();
            Document requestLog = new Document("event", "request_received")
                    .append("timestamp", new Date())
                    .append("method", "POST")
                    .append("path", request.getRequestURI())
                    .append("client_ip", request.getRemoteAddr())
                    .append("user_agent", request.getHeader("User-Agent"));

            // Read POST body
            BufferedReader reader = request.getReader();
            StringBuilder requestBody = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                requestBody.append(line);
            }

            // Parse JSON request
            JSONObject requestJson = new JSONObject(requestBody.toString());

            // Extract parameters
            String template = requestJson.optString("template", "");
            String topText = requestJson.optString("top_text", "");
            String bottomText = requestJson.optString("bottom_text", "");

            // Validate input
            if (template == null || template.trim().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                JSONObject errorJson = new JSONObject();
                errorJson.put("error", "Missing template parameter");
                out.print(errorJson.toString());

                // Log error
                requestLog.append("status", "error")
                        .append("error_message", "Missing template parameter");
                logCollection.insertOne(requestLog);
                return;
            }

            // Encode parameters for URL
            String encodedTemplate = URLEncoder.encode(template, "UTF-8");
            String encodedTopText = encodeForMeme(topText);
            String encodedBottomText = encodeForMeme(bottomText);

            // Construct API URL
            String apiUrl = String.format("https://api.memegen.link/images/%s/%s/%s",
                    encodedTemplate, encodedTopText, encodedBottomText);

            requestLog.append("parameters", new Document("template", template)
                            .append("top_text", topText)
                            .append("bottom_text", bottomText))
                    .append("api_url", apiUrl);

            // Log API request start time
            long apiRequestStartTime = System.currentTimeMillis();
            requestLog.append("api_request_start_time", new Date());

            // Call the Meme Generator API
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            // Check if the API call was successful
            int responseCode = conn.getResponseCode();

            // Log API response
            long apiRequestEndTime = System.currentTimeMillis();
            requestLog.append("api_request_end_time", new Date())
                    .append("api_response_time_ms", apiRequestEndTime - apiRequestStartTime)
                    .append("api_response_code", responseCode);

            JSONObject responseJson = new JSONObject();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Create JSON response
                responseJson.put("success", true);
                responseJson.put("url", apiUrl);
                responseJson.put("template", template);
                responseJson.put("top_text", topText);
                responseJson.put("bottom_text", bottomText);

                // Set response status
                response.setStatus(HttpServletResponse.SC_OK);

                // Log success
                requestLog.append("status", "success");
            } else {
                // Read error message from the API
                BufferedReader errorReader = new BufferedReader(
                        new InputStreamReader(conn.getErrorStream()));
                String errorContent = errorReader.lines().collect(Collectors.joining());
                errorReader.close();

                // Create error JSON response
                responseJson.put("success", false);
                responseJson.put("error", "API Error");
                responseJson.put("message", "Failed to generate meme");
                responseJson.put("api_error", errorContent);

                // Set response status
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);

                // Log error
                requestLog.append("status", "error")
                        .append("error_message", "API Error: " + errorContent);
            }

            // Send response
            out.print(responseJson.toString());

            // Log response time
            long requestEndTime = System.currentTimeMillis();
            requestLog.append("response_time_ms", requestEndTime - requestStartTime)
                    .append("response_sent", responseJson.toString());

            // Insert the complete log document
            logCollection.insertOne(requestLog);

        } catch (Exception e) {
            // Handle unexpected errors
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            JSONObject errorJson = new JSONObject();
            errorJson.put("success", false);
            errorJson.put("error", "Server Error");
            errorJson.put("message", e.getMessage());
            out.print(errorJson.toString());

            // Log error
            Document errorLog = new Document("event", "server_error")
                    .append("timestamp", new Date())
                    .append("error_type", e.getClass().getName())
                    .append("error_message", e.getMessage())
                    .append("path", request.getRequestURI())
                    .append("method", "POST");
            logCollection.insertOne(errorLog);
        }
    }

    @Override
    public void destroy() {
        // Log server shutdown
        if (logCollection != null) {
            Document serverStopLog = new Document("event", "server_stop")
                    .append("timestamp", new Date());
            logCollection.insertOne(serverStopLog);
        }

        // Close MongoDB connection
        if (mongoClient != null) {
            mongoClient.close();
        }

        super.destroy();
    }

    /**
     * Encodes text for use in the meme URL
     */
    private String encodeForMeme(String text) throws IOException {
        return URLEncoder.encode(text, "UTF-8")
                .replace("+", "%20");
    }
}