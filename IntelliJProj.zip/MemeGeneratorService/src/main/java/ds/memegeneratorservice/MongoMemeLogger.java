package ds.memegeneratorservice;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.Scanner;

/***
 * @author Madison Shen
 */
public class MongoMemeLogger {
    public static void main(String[] args) {
        // MongoDB Atlas Connection String
        String connectionString = "mongodb+srv://memeuser:jrCJYtZAbMKEfEGi@cluster0.7cbew.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

        try {
            System.out.println("Connecting to MongoDB...");
            MongoClient client = MongoClients.create(connectionString);
            System.out.println("Connected to MongoDB");

            MongoDatabase db = client.getDatabase("proj4memedb");
            System.out.println("Connected to database: " + db.getName());

            MongoCollection<Document> collection = db.getCollection("templates");
            System.out.println("Connected to collection: templates");

            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter a meme template: ");
            String input = scanner.nextLine();

            collection.insertOne(new Document("template", input).append("timestamp", new java.util.Date()));
            System.out.println("Document inserted successfully");

            System.out.println("Current templates in DB:");
            for (Document doc : collection.find()) {
                System.out.println("- " + doc.getString("template"));
            }

            client.close();
        } catch (Exception e) {
            System.out.println("MongoDB error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}