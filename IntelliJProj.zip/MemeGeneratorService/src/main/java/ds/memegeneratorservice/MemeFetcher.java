package ds.memegeneratorservice;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
/***
 * This class is for test purpose
 * @author Madison Shen
 */
public class MemeFetcher {
    public static void main(String[] args) throws UnsupportedEncodingException {
        String template = "buzz";
        String top = encodeForMeme("Projects");
        String bottom = encodeForMeme("Due Tomorrow");

        String memeUrl = String.format("https://api.memegen.link/images/%s/%s/%s", template, top, bottom);

        System.out.println("Template: " + template);
        System.out.println("Meme URL: " + memeUrl);
    }

    public static String encodeForMeme(String text) throws UnsupportedEncodingException {
        return URLEncoder.encode(text, "UTF-8")
                .replace("+", "%20");
    }
}
